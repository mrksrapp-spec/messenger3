import { useState } from 'react';
import { ArrowLeft, Plus, Pencil, Trash2 } from 'lucide-react';
import { Contact, SystemStatus } from '../App';
import { StatusBar } from './StatusBar';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from './ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from './ui/alert-dialog';

interface ContactManagerProps {
  contacts: Contact[];
  systemStatus: SystemStatus;
  onBack: () => void;
  onSave: (contacts: Contact[]) => void;
}

export function ContactManager({
  contacts,
  systemStatus,
  onBack,
  onSave
}: ContactManagerProps) {
  const [editingContact, setEditingContact] = useState<Contact | null>(null);
  const [deletingContact, setDeletingContact] = useState<Contact | null>(null);
  const [showAddDialog, setShowAddDialog] = useState(false);
  const [formData, setFormData] = useState({ name: '', status: '' });

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const handleAdd = () => {
    if (formData.name.trim()) {
      const newContact: Contact = {
        id: `c${Date.now()}`,
        name: formData.name.trim(),
        status: formData.status.trim() || undefined
      };
      onSave([...contacts, newContact]);
      setFormData({ name: '', status: '' });
      setShowAddDialog(false);
    }
  };

  const handleEdit = () => {
    if (editingContact && formData.name.trim()) {
      const updated = contacts.map(c =>
        c.id === editingContact.id
          ? { ...c, name: formData.name.trim(), status: formData.status.trim() || undefined }
          : c
      );
      onSave(updated);
      setEditingContact(null);
      setFormData({ name: '', status: '' });
    }
  };

  const handleDelete = () => {
    if (deletingContact) {
      onSave(contacts.filter(c => c.id !== deletingContact.id));
      setDeletingContact(null);
    }
  };

  const openEditDialog = (contact: Contact) => {
    setEditingContact(contact);
    setFormData({ name: contact.name, status: contact.status || '' });
  };

  return (
    <div className={`min-h-screen ${systemStatus.darkMode ? 'bg-[#121212]' : 'bg-white'}`}>
      <StatusBar systemStatus={systemStatus} />
      
      <div className={`border-b ${systemStatus.darkMode ? 'border-gray-800' : 'border-gray-200'}`}>
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={onBack}
              className={systemStatus.darkMode ? 'text-white' : ''}
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <h1 className={`text-xl ${systemStatus.darkMode ? 'text-white' : 'text-black'}`}>
              Kontakte verwalten
            </h1>
          </div>
          <Button
            onClick={() => {
              setFormData({ name: '', status: '' });
              setShowAddDialog(true);
            }}
            size="sm"
            className={
              systemStatus.darkMode
                ? 'bg-[#005c4b] hover:bg-[#004d3f]'
                : 'bg-[#25D366] hover:bg-[#20bd5a]'
            }
          >
            <Plus className="w-4 h-4 mr-1" />
            Hinzufügen
          </Button>
        </div>
      </div>

      <div className="divide-y">
        {contacts.map(contact => (
          <div
            key={contact.id}
            className={`flex items-center gap-3 p-4 ${
              systemStatus.darkMode ? 'border-gray-800' : 'border-gray-200'
            }`}
          >
            <Avatar className="w-12 h-12">
              <AvatarFallback className={systemStatus.darkMode ? 'bg-gray-700 text-white' : 'bg-gray-300'}>
                {getInitials(contact.name)}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1 min-w-0">
              <h3 className={`truncate ${systemStatus.darkMode ? 'text-white' : 'text-black'}`}>
                {contact.name}
              </h3>
              {contact.status && (
                <p className={`text-sm truncate ${systemStatus.darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  {contact.status}
                </p>
              )}
            </div>

            <div className="flex gap-1">
              <Button
                variant="ghost"
                size="icon"
                onClick={() => openEditDialog(contact)}
                className={systemStatus.darkMode ? 'text-white hover:bg-gray-800' : ''}
              >
                <Pencil className="w-4 h-4" />
              </Button>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setDeletingContact(contact)}
                className={systemStatus.darkMode ? 'text-red-400 hover:bg-gray-800' : 'text-red-600'}
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>

      {contacts.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20">
          <p className={`text-center ${systemStatus.darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            Noch keine Kontakte.
            <br />
            Tippe auf "Hinzufügen" um einen Kontakt zu erstellen.
          </p>
        </div>
      )}

      {/* Add Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className={systemStatus.darkMode ? 'bg-gray-900 text-white' : ''}>
          <DialogHeader>
            <DialogTitle>Neuer Kontakt</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Name *</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Max Mustermann"
                className={systemStatus.darkMode ? 'bg-gray-800 border-gray-700' : ''}
              />
            </div>
            <div className="space-y-2">
              <Label>Status (optional)</Label>
              <Input
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                placeholder="online, zuletzt heute um 14:22..."
                className={systemStatus.darkMode ? 'bg-gray-800 border-gray-700' : ''}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>
              Abbrechen
            </Button>
            <Button onClick={handleAdd} disabled={!formData.name.trim()}>
              Hinzufügen
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Dialog */}
      <Dialog open={!!editingContact} onOpenChange={() => setEditingContact(null)}>
        <DialogContent className={systemStatus.darkMode ? 'bg-gray-900 text-white' : ''}>
          <DialogHeader>
            <DialogTitle>Kontakt bearbeiten</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Name *</Label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Max Mustermann"
                className={systemStatus.darkMode ? 'bg-gray-800 border-gray-700' : ''}
              />
            </div>
            <div className="space-y-2">
              <Label>Status (optional)</Label>
              <Input
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                placeholder="online, zuletzt heute um 14:22..."
                className={systemStatus.darkMode ? 'bg-gray-800 border-gray-700' : ''}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditingContact(null)}>
              Abbrechen
            </Button>
            <Button onClick={handleEdit} disabled={!formData.name.trim()}>
              Speichern
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deletingContact} onOpenChange={() => setDeletingContact(null)}>
        <AlertDialogContent className={systemStatus.darkMode ? 'bg-gray-900 text-white' : ''}>
          <AlertDialogHeader>
            <AlertDialogTitle>Kontakt löschen?</AlertDialogTitle>
            <AlertDialogDescription className={systemStatus.darkMode ? 'text-gray-400' : ''}>
              Möchtest du {deletingContact?.name} wirklich löschen? Diese Aktion kann nicht rückgängig gemacht werden.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Abbrechen</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600 hover:bg-red-700">
              Löschen
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
