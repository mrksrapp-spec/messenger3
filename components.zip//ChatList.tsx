import { Plus, Settings } from 'lucide-react';
import { Contact, Message, SystemStatus } from '../App';
import { StatusBar } from './StatusBar';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Button } from './ui/button';

interface ChatListProps {
  contacts: Contact[];
  chats: Record<string, Message[]>;
  sessionMessages: Record<string, Message[]>;
  systemStatus: SystemStatus;
  onOpenChat: (contactId: string) => void;
  onOpenContacts: () => void;
  onOpenDebug: () => void;
}

export function ChatList({
  contacts,
  chats,
  sessionMessages,
  systemStatus,
  onOpenChat,
  onOpenContacts,
  onOpenDebug
}: ChatListProps) {
  const getLastMessage = (contactId: string) => {
    const persistent = chats[contactId] || [];
    const session = sessionMessages[contactId] || [];
    const all = [...persistent, ...session];
    return all[all.length - 1];
  };

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  return (
    <div className={`min-h-screen ${systemStatus.darkMode ? 'bg-[#121212]' : 'bg-white'}`}>
      <StatusBar systemStatus={systemStatus} />
      
      <div className={`border-b ${systemStatus.darkMode ? 'border-gray-800' : 'border-gray-200'}`}>
        <div className="flex items-center justify-between p-4">
          <h1 className={`text-2xl ${systemStatus.darkMode ? 'text-white' : 'text-black'}`}>Nachrichten</h1>
          <div className="flex gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={onOpenContacts}
              className={systemStatus.darkMode ? 'text-white hover:bg-gray-800' : ''}
            >
              <Plus className="w-5 h-5" />
            </Button>
            <Button
              variant="ghost"
              size="icon"
              onClick={onOpenDebug}
              className={systemStatus.darkMode ? 'text-white hover:bg-gray-800' : ''}
            >
              <Settings className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>

      <div className="divide-y">
        {contacts.map(contact => {
          const lastMsg = getLastMessage(contact.id);
          return (
            <div
              key={contact.id}
              onClick={() => onOpenChat(contact.id)}
              className={`flex items-center gap-3 p-4 cursor-pointer ${
                systemStatus.darkMode
                  ? 'hover:bg-gray-900 border-gray-800'
                  : 'hover:bg-gray-50 border-gray-200'
              }`}
            >
              <Avatar className="w-12 h-12">
                <AvatarFallback className={systemStatus.darkMode ? 'bg-gray-700 text-white' : 'bg-gray-300'}>
                  {getInitials(contact.name)}
                </AvatarFallback>
              </Avatar>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <h3 className={`truncate ${systemStatus.darkMode ? 'text-white' : 'text-black'}`}>
                    {contact.name}
                  </h3>
                  {lastMsg && (
                    <span className={`text-xs ${systemStatus.darkMode ? 'text-gray-400' : 'text-gray-500'}`}>
                      {lastMsg.time}
                    </span>
                  )}
                </div>
                <p className={`text-sm truncate ${systemStatus.darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
                  {lastMsg ? (lastMsg.from === 'me' ? 'Du: ' : '') + lastMsg.text : 'Noch keine Nachrichten'}
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {contacts.length === 0 && (
        <div className="flex flex-col items-center justify-center py-20">
          <p className={`text-center ${systemStatus.darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
            Noch keine Kontakte.
            <br />
            Tippe auf + um Kontakte hinzuzufügen.
          </p>
        </div>
      )}
    </div>
  );
}
