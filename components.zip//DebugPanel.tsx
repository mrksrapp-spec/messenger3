import { useState } from 'react';
import { X, Play, RotateCcw, Zap, Moon, Sun } from 'lucide-react';
import { AppData } from '../App';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Slider } from './ui/slider';
import { Switch } from './ui/switch';
import { Separator } from './ui/separator';
import { ScrollArea } from './ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface DebugPanelProps {
  appData: AppData;
  onClose: () => void;
  onUpdate: (data: AppData) => void;
  onResetSession: () => void;
  onTriggerAll: () => void;
}

export function DebugPanel({
  appData,
  onClose,
  onUpdate,
  onResetSession,
  onTriggerAll
}: DebugPanelProps) {
  const [localData, setLocalData] = useState(appData);

  const updateSystemStatus = (updates: Partial<typeof appData.systemStatus>) => {
    const newData = {
      ...localData,
      systemStatus: { ...localData.systemStatus, ...updates }
    };
    setLocalData(newData);
    onUpdate(newData);
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end sm:items-center justify-center p-4">
      <div className="bg-white dark:bg-gray-900 rounded-t-2xl sm:rounded-2xl w-full max-w-2xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-lg">Debug / Regie-Panel</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        {/* Content */}
        <ScrollArea className="flex-1">
          <div className="p-4">
            <Tabs defaultValue="system" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="system">System</TabsTrigger>
                <TabsTrigger value="triggers">Trigger</TabsTrigger>
                <TabsTrigger value="data">Daten</TabsTrigger>
              </TabsList>

              {/* System Tab */}
              <TabsContent value="system" className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label>Uhrzeit</Label>
                  <Input
                    type="time"
                    value={localData.systemStatus.time}
                    onChange={(e) => updateSystemStatus({ time: e.target.value })}
                  />
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label>Akku: {localData.systemStatus.battery.percent}%</Label>
                  <Slider
                    value={[localData.systemStatus.battery.percent]}
                    onValueChange={([value]) =>
                      updateSystemStatus({
                        battery: { ...localData.systemStatus.battery, percent: value }
                      })
                    }
                    min={0}
                    max={100}
                    step={1}
                  />
                  <div className="flex items-center gap-2">
                    <Switch
                      checked={localData.systemStatus.battery.charging}
                      onCheckedChange={(checked) =>
                        updateSystemStatus({
                          battery: { ...localData.systemStatus.battery, charging: checked }
                        })
                      }
                    />
                    <Label>Lädt</Label>
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label>WLAN-Stärke: {localData.systemStatus.wifi} Balken</Label>
                  <Slider
                    value={[localData.systemStatus.wifi]}
                    onValueChange={([value]) => updateSystemStatus({ wifi: value })}
                    min={0}
                    max={4}
                    step={1}
                  />
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label>Netzwerktyp</Label>
                  <Input
                    value={localData.systemStatus.network.type}
                    onChange={(e) =>
                      updateSystemStatus({
                        network: { ...localData.systemStatus.network, type: e.target.value }
                      })
                    }
                    placeholder="5G, 4G, LTE..."
                  />
                </div>

                <div className="space-y-2">
                  <Label>Provider</Label>
                  <Input
                    value={localData.systemStatus.network.provider}
                    onChange={(e) =>
                      updateSystemStatus({
                        network: { ...localData.systemStatus.network, provider: e.target.value }
                      })
                    }
                    placeholder="MockTel"
                  />
                </div>

                <Separator />

                <div className="flex items-center justify-between">
                  <Label>Dark Mode</Label>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => updateSystemStatus({ darkMode: !localData.systemStatus.darkMode })}
                  >
                    {localData.systemStatus.darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
                  </Button>
                </div>
              </TabsContent>

              {/* Triggers Tab */}
              <TabsContent value="triggers" className="space-y-4 mt-4">
                <div className="grid grid-cols-2 gap-2">
                  <Button onClick={onTriggerAll} className="w-full">
                    <Play className="w-4 h-4 mr-2" />
                    Alle Trigger
                  </Button>
                  <Button onClick={onResetSession} variant="outline" className="w-full">
                    <RotateCcw className="w-4 h-4 mr-2" />
                    Session Reset
                  </Button>
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label>Konfigurierte Trigger</Label>
                  {localData.fakeTriggers.length === 0 ? (
                    <p className="text-sm text-gray-500">Noch keine Trigger konfiguriert</p>
                  ) : (
                    <div className="space-y-2">
                      {localData.fakeTriggers.map((trigger) => {
                        const contact = localData.contacts.find(c => c.id === trigger.chatId);
                        return (
                          <div
                            key={trigger.id}
                            className="p-3 border rounded-lg space-y-1"
                          >
                            <div className="flex items-center justify-between">
                              <span className="text-sm">
                                {contact?.name || 'Unbekannt'}
                              </span>
                              <span className="text-xs text-gray-500">
                                {trigger.type === 'timer' 
                                  ? `${trigger.delaySec}s Timer`
                                  : 'Tap-basiert'
                                }
                              </span>
                            </div>
                            <p className="text-xs text-gray-600">{trigger.message.text}</p>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>

                <div className="p-3 bg-blue-50 dark:bg-blue-950 rounded-lg">
                  <p className="text-xs text-blue-900 dark:text-blue-100">
                    <strong>Hinweis:</strong> Timer-Trigger starten automatisch beim Öffnen eines Chats. 
                    Tap-Trigger werden durch Tippen auf den Chat-Bereich ausgelöst.
                  </p>
                </div>
              </TabsContent>

              {/* Data Tab */}
              <TabsContent value="data" className="space-y-4 mt-4">
                <div className="space-y-2">
                  <Label>Kontakte: {localData.contacts.length}</Label>
                  <div className="text-sm text-gray-600">
                    {localData.contacts.map(c => c.name).join(', ') || 'Keine Kontakte'}
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label>Gespeicherte Chats: {Object.keys(localData.chats).length}</Label>
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label>JSON Export/Import</Label>
                  <div className="grid grid-cols-2 gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        const dataStr = JSON.stringify(localData, null, 2);
                        const blob = new Blob([dataStr], { type: 'application/json' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        a.download = 'mockup-messenger-data.json';
                        a.click();
                      }}
                    >
                      Export JSON
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => {
                        const input = document.createElement('input');
                        input.type = 'file';
                        input.accept = '.json';
                        input.onchange = (e) => {
                          const file = (e.target as HTMLInputElement).files?.[0];
                          if (file) {
                            const reader = new FileReader();
                            reader.onload = (e) => {
                              try {
                                const data = JSON.parse(e.target?.result as string);
                                setLocalData(data);
                                onUpdate(data);
                              } catch (err) {
                                alert('Fehler beim Laden der JSON-Datei');
                              }
                            };
                            reader.readAsText(file);
                          }
                        };
                        input.click();
                      }}
                    >
                      Import JSON
                    </Button>
                  </div>
                </div>

                <div className="p-3 bg-yellow-50 dark:bg-yellow-950 rounded-lg">
                  <p className="text-xs text-yellow-900 dark:text-yellow-100">
                    <strong>Wichtig:</strong> Session-Nachrichten (vom Senden-Button) werden nach App-Neustart gelöscht. 
                    Nur vorbereitete Chatverläufe bleiben gespeichert.
                  </p>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </ScrollArea>

        {/* Footer */}
        <div className="p-4 border-t">
          <Button onClick={onClose} className="w-full">
            Schließen
          </Button>
        </div>
      </div>
    </div>
  );
}
