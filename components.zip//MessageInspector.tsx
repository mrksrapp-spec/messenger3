import { X } from 'lucide-react';
import { Message, Contact } from '../App';
import { Button } from './ui/button';
import { motion } from 'motion/react';

interface MessageInspectorProps {
  message: Message;
  contact?: Contact;
  onClose: () => void;
}

export function MessageInspector({ message, contact, onClose }: MessageInspectorProps) {
  const isMe = message.from === 'me';
  const senderName = isMe ? 'Du' : contact?.name || 'Unbekannt';

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-8"
      onClick={onClose}
    >
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ type: 'spring', duration: 0.5 }}
        className="bg-white dark:bg-gray-900 rounded-2xl p-8 max-w-2xl w-full"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-start justify-between mb-6">
          <div>
            <h2 className="text-2xl mb-2">Nachricht</h2>
            <p className="text-gray-600 dark:text-gray-400">
              Von: <span className="font-medium">{senderName}</span>
            </p>
          </div>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        <div className="space-y-6">
          <div className="p-6 bg-gray-50 dark:bg-gray-800 rounded-lg">
            <p className="text-2xl leading-relaxed break-words">{message.text}</p>
          </div>

          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
              <p className="text-gray-600 dark:text-gray-400 mb-1">Zeitstempel</p>
              <p className="text-lg">{message.time}</p>
            </div>

            {message.status && (
              <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-lg">
                <p className="text-gray-600 dark:text-gray-400 mb-1">Status</p>
                <p className="text-lg">
                  {message.status === 'sent' && '✓ Gesendet'}
                  {message.status === 'delivered' && '✓✓ Zugestellt'}
                  {message.status === 'read' && '✓✓ Gelesen'}
                </p>
              </div>
            )}
          </div>

          <div className="text-xs text-gray-500 dark:text-gray-600 text-center">
            Diese Ansicht ist optimiert für Close-Up Aufnahmen
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}
