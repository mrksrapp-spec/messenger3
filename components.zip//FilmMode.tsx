import { useState, useEffect } from 'react';
import { Camera, CameraOff, Info } from 'lucide-react';
import { Button } from './ui/button';
import { toast } from 'sonner@2.0.3';

interface FilmModeProps {
  darkMode: boolean;
}

export function FilmMode({ darkMode }: FilmModeProps) {
  const [isFilmMode, setIsFilmMode] = useState(false);
  const [showInfo, setShowInfo] = useState(false);

  useEffect(() => {
    // Check if film mode was previously enabled
    const saved = localStorage.getItem('filmModeEnabled');
    if (saved === 'true') {
      enableFilmMode();
    }
  }, []);

  const enableFilmMode = () => {
    setIsFilmMode(true);
    localStorage.setItem('filmModeEnabled', 'true');
    
    // Scroll down to hide Chrome address bar
    window.scrollTo(0, 1);
    
    // Lock orientation to portrait
    if (screen.orientation && screen.orientation.lock) {
      screen.orientation.lock('portrait').catch(() => {});
    }
    
    // Hide scrollbars
    document.documentElement.style.overflow = 'hidden';
    document.body.style.overflow = 'hidden';
    
    // Set viewport height
    const setVH = () => {
      const vh = window.innerHeight * 0.01;
      document.documentElement.style.setProperty('--vh', `${vh}px`);
    };
    setVH();
    window.addEventListener('resize', setVH);
    
    toast.success('Film-Modus aktiviert', {
      description: 'Scrolle einmal nach unten um Chrome-Leiste zu verstecken'
    });
  };

  const disableFilmMode = () => {
    setIsFilmMode(false);
    localStorage.setItem('filmModeEnabled', 'false');
    
    // Restore scrolling
    document.documentElement.style.overflow = '';
    document.body.style.overflow = '';
    
    toast.info('Film-Modus deaktiviert');
  };

  const toggleFilmMode = () => {
    if (isFilmMode) {
      disableFilmMode();
    } else {
      enableFilmMode();
    }
  };

  return (
    <>
      {/* Info Popup */}
      {showInfo && (
        <div className="fixed inset-0 bg-black/80 z-[100] flex items-center justify-center p-4" onClick={() => setShowInfo(false)}>
          <div className={`max-w-md p-6 rounded-lg ${darkMode ? 'bg-gray-900 text-white' : 'bg-white text-black'}`} onClick={e => e.stopPropagation()}>
            <h3 className="mb-3">Film-Modus Info</h3>
            <div className="space-y-3 text-sm">
              <p>
                <strong>Was ist Film-Modus?</strong><br/>
                Optimiert die App für Filmaufnahmen durch:
              </p>
              <ul className="list-disc list-inside space-y-1 ml-2">
                <li>Fixierte Viewport-Höhe</li>
                <li>Versteckte Scrollbars</li>
                <li>Portrait-Modus gesperrt</li>
                <li>Optimiert für Handy-Aufnahmen</li>
              </ul>
              <div className={`p-3 rounded ${darkMode ? 'bg-yellow-900/30 text-yellow-200' : 'bg-yellow-50 text-yellow-900'}`}>
                <strong>Wichtig:</strong> Nach Aktivierung einmal nach unten scrollen, dann bleibt die Chrome-Adressleiste minimal!
              </div>
              <p className="text-xs opacity-70">
                Für echten Fullscreen (ohne Browser-UI) musst du die App auf einem eigenen Server hosten und als PWA installieren.
              </p>
            </div>
            <Button
              onClick={() => setShowInfo(false)}
              className={`w-full mt-4 ${
                darkMode
                  ? 'bg-[#005c4b] hover:bg-[#004d3f]'
                  : 'bg-[#25D366] hover:bg-[#20bd5a]'
              }`}
            >
              Verstanden
            </Button>
          </div>
        </div>
      )}

      {/* Control Buttons */}
      <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2">
        <Button
          onClick={() => setShowInfo(true)}
          size="icon"
          variant="outline"
          className={`rounded-full w-10 h-10 ${
            darkMode
              ? 'bg-gray-800 border-gray-700 text-white hover:bg-gray-700'
              : 'bg-white border-gray-300 hover:bg-gray-100'
          }`}
        >
          <Info className="w-4 h-4" />
        </Button>
        
        <Button
          onClick={toggleFilmMode}
          size="icon"
          className={`rounded-full w-14 h-14 shadow-xl transition-all ${
            isFilmMode
              ? 'bg-red-500 hover:bg-red-600 text-white animate-pulse'
              : darkMode
                ? 'bg-[#005c4b] hover:bg-[#004d3f] text-white'
                : 'bg-[#25D366] hover:bg-[#20bd5a] text-white'
          }`}
        >
          {isFilmMode ? (
            <CameraOff className="w-6 h-6" />
          ) : (
            <Camera className="w-6 h-6" />
          )}
        </Button>
      </div>

      {/* Film Mode Indicator */}
      {isFilmMode && (
        <div className="fixed top-0 left-0 right-0 z-[60] flex items-center justify-center pointer-events-none">
          <div className="bg-red-500 text-white px-4 py-1 rounded-b-lg text-xs font-mono shadow-lg flex items-center gap-2">
            <div className="w-2 h-2 bg-white rounded-full animate-pulse" />
            FILM-MODUS AKTIV
          </div>
        </div>
      )}
    </>
  );
}
