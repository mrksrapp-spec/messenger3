import { Wifi, Battery, BatteryCharging } from 'lucide-react';
import { SystemStatus } from '../App';

interface StatusBarProps {
  systemStatus: SystemStatus;
}

export function StatusBar({ systemStatus }: StatusBarProps) {
  const { time, battery, wifi, network, darkMode } = systemStatus;

  const getWifiIcon = () => {
    const bars = wifi;
    return (
      <div className="flex items-end gap-[1px] h-3">
        {[1, 2, 3, 4].map(bar => (
          <div
            key={bar}
            className={`w-[2px] ${bar <= bars ? (darkMode ? 'bg-white' : 'bg-black') : 'bg-gray-400'}`}
            style={{ height: `${bar * 3}px` }}
          />
        ))}
      </div>
    );
  };

  return (
    <div className={`flex items-center justify-between px-6 pt-3 pb-2 ${darkMode ? 'text-white' : 'text-black'}`}>
      <div className="flex items-center gap-2 text-xs">
        <span>{time}</span>
      </div>

      <div className="absolute left-1/2 -translate-x-1/2 top-3">
        <span className="text-[9px] opacity-50 tracking-wide">MOCKUP / DREHARBEIT</span>
      </div>

      <div className="flex items-center gap-2 text-xs">
        <span className="text-[10px]">{network.type}</span>
        {getWifiIcon()}
        <div className="flex items-center gap-1">
          <span className="text-[10px]">{battery.percent}%</span>
          {battery.charging ? (
            <BatteryCharging className="w-4 h-4" />
          ) : (
            <Battery className="w-4 h-4" />
          )}
        </div>
      </div>
    </div>
  );
}
