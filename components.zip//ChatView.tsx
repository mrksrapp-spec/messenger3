import { useState, useEffect, useRef } from 'react';
import { ArrowLeft, Send } from 'lucide-react';
import { Contact, Message, SystemStatus, FakeTrigger } from '../App';
import { StatusBar } from './StatusBar';
import { Avatar, AvatarFallback } from './ui/avatar';
import { Button } from './ui/button';
import { Input } from './ui/input';

interface ChatViewProps {
  contact: Contact;
  messages: Message[];
  systemStatus: SystemStatus;
  fakeTriggers: FakeTrigger[];
  activeTriggers: Set<string>;
  onBack: () => void;
  onSendMessage: (text: string) => void;
  onMessageClick: (message: Message) => void;
  onTriggerActivated: (triggerId: string) => void;
  onFakeMessage: (message: Omit<Message, 'id'>) => void;
}

export function ChatView({
  contact,
  messages,
  systemStatus,
  fakeTriggers,
  activeTriggers,
  onBack,
  onSendMessage,
  onMessageClick,
  onTriggerActivated,
  onFakeMessage
}: ChatViewProps) {
  const [inputText, setInputText] = useState('');
  const [typingUsers, setTypingUsers] = useState<Set<string>>(new Set());
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const tapTriggersRef = useRef<FakeTrigger[]>([]);

  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, typingUsers]);

  // Set up timer-based triggers
  useEffect(() => {
    const timerTriggers = fakeTriggers.filter(t => t.type === 'timer' && !activeTriggers.has(t.id));
    
    timerTriggers.forEach(trigger => {
      const timeout = setTimeout(() => {
        // Show typing indicator if configured
        if (trigger.showTyping) {
          setTypingUsers(prev => new Set([...prev, trigger.message.from as string]));
          
          setTimeout(() => {
            setTypingUsers(prev => {
              const next = new Set(prev);
              next.delete(trigger.message.from as string);
              return next;
            });
            onFakeMessage(trigger.message);
            onTriggerActivated(trigger.id);
          }, (trigger.typingDuration || 2) * 1000);
        } else {
          onFakeMessage(trigger.message);
          onTriggerActivated(trigger.id);
        }
      }, (trigger.delaySec || 0) * 1000);

      return () => clearTimeout(timeout);
    });
  }, [fakeTriggers, activeTriggers]);

  // Set up tap-based triggers
  useEffect(() => {
    tapTriggersRef.current = fakeTriggers.filter(t => t.type === 'tap' && !activeTriggers.has(t.id));
  }, [fakeTriggers, activeTriggers]);

  const handleScreenTap = (e: React.MouseEvent | React.TouchEvent) => {
    // Only trigger if tapping on the messages area, not on input or buttons
    const target = e.target as HTMLElement;
    if (target.closest('.chat-input') || target.closest('button')) {
      return;
    }

    if (tapTriggersRef.current.length > 0) {
      const trigger = tapTriggersRef.current[0];
      
      if (trigger.showTyping) {
        setTypingUsers(prev => new Set([...prev, trigger.message.from as string]));
        
        setTimeout(() => {
          setTypingUsers(prev => {
            const next = new Set(prev);
            next.delete(trigger.message.from as string);
            return next;
          });
          onFakeMessage(trigger.message);
          onTriggerActivated(trigger.id);
        }, (trigger.typingDuration || 2) * 1000);
      } else {
        onFakeMessage(trigger.message);
        onTriggerActivated(trigger.id);
      }
    }
  };

  const handleSend = () => {
    if (inputText.trim()) {
      onSendMessage(inputText);
      setInputText('');
    }
  };

  const renderStatus = (status?: string) => {
    if (!status || status === 'sent') {
      return <span className="text-gray-400">✓</span>;
    }
    if (status === 'delivered') {
      return <span className="text-gray-400">✓✓</span>;
    }
    if (status === 'read') {
      return <span className="text-blue-500">✓✓</span>;
    }
  };

  return (
    <div
      className={`min-h-screen flex flex-col ${systemStatus.darkMode ? 'bg-[#121212]' : 'bg-[#ECE5DD]'}`}
      onClick={handleScreenTap}
      onTouchEnd={handleScreenTap}
    >
      <StatusBar systemStatus={systemStatus} />
      
      {/* Header */}
      <div className={`flex items-center gap-3 p-3 border-b ${
        systemStatus.darkMode ? 'bg-[#1f1f1f] border-gray-800' : 'bg-white border-gray-200'
      }`}>
        <Button variant="ghost" size="icon" onClick={onBack} className={systemStatus.darkMode ? 'text-white' : ''}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        
        <Avatar className="w-10 h-10">
          <AvatarFallback className={systemStatus.darkMode ? 'bg-gray-700 text-white' : 'bg-gray-300'}>
            {getInitials(contact.name)}
          </AvatarFallback>
        </Avatar>
        
        <div className="flex-1">
          <h2 className={systemStatus.darkMode ? 'text-white' : 'text-black'}>{contact.name}</h2>
          {contact.status && (
            <p className={`text-xs ${systemStatus.darkMode ? 'text-gray-400' : 'text-gray-600'}`}>
              {contact.status}
            </p>
          )}
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2">
        {messages.map((msg) => {
          const isMe = msg.from === 'me';
          return (
            <div
              key={msg.id}
              className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}
              onClick={(e) => {
                e.stopPropagation();
                onMessageClick(msg);
              }}
            >
              <div
                className={`max-w-[75%] rounded-lg px-3 py-2 ${
                  isMe
                    ? systemStatus.darkMode
                      ? 'bg-[#005c4b] text-white'
                      : 'bg-[#DCF8C6] text-black'
                    : systemStatus.darkMode
                    ? 'bg-[#1f1f1f] text-white'
                    : 'bg-white text-black'
                }`}
                style={{ boxShadow: '0 1px 0.5px rgba(0,0,0,0.13)' }}
              >
                <p className="break-words">{msg.text}</p>
                <div className={`flex items-center justify-end gap-1 text-[10px] mt-1 ${
                  isMe 
                    ? systemStatus.darkMode ? 'text-gray-300' : 'text-gray-700'
                    : systemStatus.darkMode ? 'text-gray-400' : 'text-gray-600'
                }`}>
                  <span>{msg.time}</span>
                  {isMe && renderStatus(msg.status)}
                </div>
              </div>
            </div>
          );
        })}

        {/* Typing indicator */}
        {typingUsers.size > 0 && (
          <div className="flex justify-start">
            <div className={`rounded-lg px-3 py-2 ${
              systemStatus.darkMode ? 'bg-[#1f1f1f]' : 'bg-white'
            }`}>
              <div className="flex gap-1">
                <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className={`chat-input p-3 border-t ${
        systemStatus.darkMode ? 'bg-[#1f1f1f] border-gray-800' : 'bg-white border-gray-200'
      }`}>
        <div className="flex items-center gap-2">
          <Input
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Nachricht"
            className={`flex-1 ${
              systemStatus.darkMode
                ? 'bg-[#121212] border-gray-700 text-white placeholder:text-gray-500'
                : 'bg-gray-100 border-gray-300'
            }`}
          />
          <Button
            onClick={handleSend}
            size="icon"
            className={
              systemStatus.darkMode
                ? 'bg-[#005c4b] hover:bg-[#004d3f] text-white'
                : 'bg-[#25D366] hover:bg-[#20bd5a] text-white'
            }
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
